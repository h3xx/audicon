#!/bin/sh

tar czf "`date '+%Y-%m%d-%H%M'`_audicon.tar.gz" audicon/*.sci
